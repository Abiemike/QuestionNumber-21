﻿using System;
namespace QuestionNumber21;
public class TemperatureEventArgs : EventArgs
{
    public double Temperature { get; }

    public TemperatureEventArgs(double temperature)
    {
        Temperature = temperature;
    }
}
