﻿namespace QuestionNumber21;

public class TemperatureAlarm
{
    private readonly TemperatureSensor _sensor;

    public TemperatureAlarm(TemperatureSensor sensor)
    {
        _sensor = sensor;
        
        _sensor.TemperatureChanged += HandleTemperatureChange;
    }

    // Event handler method
    private void HandleTemperatureChange(object sender, TemperatureEventArgs e)
    {
        if (e.Temperature > 30.0) // 
        {
            Console.WriteLine($"Alarm! Temperature has exceeded the threshold: {e.Temperature}°C");
        }
        else
        {
            Console.WriteLine($"Temperature is normal: {e.Temperature}°C");
        }
    }
}
