﻿namespace QuestionNumber21;
class Program
{
    static void Main(string[] args)
    {
        // Create an instance of the temperature sensor
        var sensor = new TemperatureSensor();

        // Create an instance of the alarm system which subscribes to the event
        var alarm = new TemperatureAlarm(sensor);

        // Change the temperature to trigger the event
        sensor.CurrentTemperature = 20; // This will print "Temperature is normal: 28°C"
        sensor.CurrentTemperature = 40; // This will print "Alarm! Temperature has exceeded the threshold: 35°C"
    }
}
