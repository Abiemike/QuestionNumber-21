﻿namespace QuestionNumber21;
public class TemperatureSensor
{
    public delegate void TemperatureChangedEventHandler(object sender, TemperatureEventArgs e);

    public event TemperatureChangedEventHandler TemperatureChanged;

    private double currentTemperature;

    public double CurrentTemperature
    {
        get { return currentTemperature; }
        set
        {
            
            currentTemperature = value;
            OnTemperatureChanged(new TemperatureEventArgs(currentTemperature));
        }
    }

       protected virtual void OnTemperatureChanged(TemperatureEventArgs e)
    {
        
        TemperatureChanged?.Invoke(this, e);
    }
}
